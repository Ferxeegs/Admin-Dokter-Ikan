declare module 'jsvectormap' {
    const jsVectorMap: any;
    export default jsVectorMap;
}
