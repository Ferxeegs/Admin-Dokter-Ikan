export interface Vendor {
    vendor_id: number;
    vendor_name: string;
    vendor_address: string;
    contact: string;
  }
    