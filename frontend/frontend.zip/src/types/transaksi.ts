export type Transaksi = {
    name: string;
    email: string;
    topikKonsultasi: string;
    obat: string;
    chat: number;
    total: string;
    status: string;
    user_consultation_id: number;
  };
  