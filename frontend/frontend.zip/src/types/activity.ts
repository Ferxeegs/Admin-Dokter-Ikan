export type Activity = {
    name: string;
    email: string;
    topic: string;
    tenagaAhli: string;
    status: string;
    consultation_id: number;
  };