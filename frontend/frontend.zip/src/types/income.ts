export type INCOME = {
  logo: string;
  name: string;
  date: string;
  revenues: string;
};
