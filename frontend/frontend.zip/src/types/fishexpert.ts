export interface FishExpert {
    fishExperts_id: number;
    name: string;
    phone_number: string;
    specialization: string;
    experience: string;
    email: string;
    role: string;
    image_url: string;
  }
  